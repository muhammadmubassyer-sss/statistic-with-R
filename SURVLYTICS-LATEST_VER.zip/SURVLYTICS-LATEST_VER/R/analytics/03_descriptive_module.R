descriptive_ui <- function(id) {
  ns <- NS(id)
  tagList(
    layout_sidebar(
      sidebar = sidebar(
        selectInput(ns("var_select"), "Select Variable:", choices = NULL),
        checkboxInput(ns("show_plot"), "Generate Distribution Plot", value = TRUE),
        actionButton(ns("save_desc"), "Save to Report", class = "btn-primary w-100")
      ),
      card(
        card_header("Summary Statistics"),
        DTOutput(ns("desc_table"))
      ),
      card(
        card_header("Distribution Visual"),
        plotOutput(ns("desc_plot"))
      )
    )
  )
}

descriptive_server <- function(id, app_state) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns
    
    observe({
      req(app_state$data)
      updateSelectInput(session, "var_select", choices = names(app_state$data))
    })
    
    calc_stats <- reactive({
      req(app_state$data, input$var_select)
      df <- app_state$data
      var <- df[[input$var_select]]
      
      if (is.numeric(var)) {
        data.frame(
          Metric = c("Mean", "SD", "Median", "Min", "Max"),
          Value = c(mean(var, na.rm = TRUE), sd(var, na.rm = TRUE), median(var, na.rm = TRUE), min(var, na.rm = TRUE), max(var, na.rm = TRUE))
        )
      } else {
        as.data.frame(table(Variable = var))
      }
    })
    
    output$desc_table <- renderDT({
      datatable(calc_stats(), options = list(dom = 't'))
    })
    
    output$desc_plot <- renderPlot({
      req(input$show_plot, input$var_select)
      df <- app_state$data
      var_name <- input$var_select
      
      if (is.numeric(df[[var_name]])) {
        ggplot(df, aes_string(x = var_name)) +
          geom_histogram(fill = "#3498db", color = "white", bins = 20) +
          theme_minimal() + labs(title = paste("Histogram of", var_name))
      } else {
        ggplot(df, aes_string(x = var_name)) +
          geom_bar(fill = "#2ecc71") +
          theme_minimal() + labs(title = paste("Frequency of", var_name))
      }
    })
    
    observeEvent(input$save_desc, {
      app_state$final_models$descriptive <- list(
        variable = input$var_select,
        summary = calc_stats()
      )
      showNotification("Descriptive stats saved to summary report!", type = "message")
    })
  })
}