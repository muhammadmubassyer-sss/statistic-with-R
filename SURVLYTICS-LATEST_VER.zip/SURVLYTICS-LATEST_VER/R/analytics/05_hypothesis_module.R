hypothesis_ui <- function(id) {
  ns <- NS(id)
  tagList(
    layout_sidebar(
      sidebar = sidebar(
        selectInput(ns("var_x"), "Grouping / Categorical Variable:", choices = NULL),
        selectInput(ns("var_y"), "Numeric / Outcome Variable:", choices = NULL),
        selectInput(ns("test_type"), "Select Test:", choices = c("t-test", "ANOVA", "Chi-Square")),
        actionButton(ns("run_test"), "Run & Save to Report", class = "btn-primary w-100")
      ),
      card(
        card_header("Hypothesis Test Output"),
        verbatimTextOutput(ns("test_out"))
      )
    )
  )
}

hypothesis_server <- function(id, app_state) {
  moduleServer(id, function(input, output, session) {
    
    observe({
      req(app_state$data)
      updateSelectInput(session, "var_x", choices = names(app_state$data), selected = "Species")
      updateSelectInput(session, "var_y", choices = names(app_state$data), selected = "Petal.Width")
    })
    
    test_result <- eventReactive(input$run_test, {
      req(input$var_x, input$var_y, app_state$data)
      df <- app_state$data
      
      res <- tryCatch({
        if (input$test_type == "t-test") {
          t.test(df[[input$var_y]] ~ df[[input$var_x]])
        } else if (input$test_type == "ANOVA") {
          aov_fit <- aov(df[[input$var_y]] ~ df[[input$var_x]])
          summary(aov_fit)
        } else if (input$test_type == "Chi-Square") {
          chisq.test(table(df[[input$var_x]], df[[input$var_y]]))
        }
      }, error = function(e) {
        paste("Error running test:", e$message, "\nTip: Use ANOVA for categorical variables with 3+ groups (like Species).")
      })
      
      # Save state to turn the Hypothesis box GREEN in Final Summary & Workflow
      app_state$final_models$hypothesis <- list(
        var_x = input$var_x,
        var_y = input$var_y,
        test_type = input$test_type,
        result = res
      )
      
      res
    })
    
    output$test_out <- renderPrint({
      req(test_result())
      test_result()
    })
  })
}