library(shiny)
library(DiagrammeR)
library(officer)
library(flextable)

summary_report_ui <- function(id) {
  ns <- NS(id)
  tagList(
    card(
      card_header("Interactive Analysis Workflow"),
      grVizOutput(ns("workflow_graph"), height = "280px")
    ),
    card(
      card_header("Report Preview & Export"),
      uiOutput(ns("report_summary")),
      hr(),
      downloadButton(ns("download_docx"), "Export Professional Word Report (.docx)", class = "btn-success w-100")
    )
  )
}

summary_report_server <- function(id, app_state) {
  moduleServer(id, function(input, output, session) {
    
    # Workflow Graph Rendering
    output$workflow_graph <- renderGrViz({
      m <- app_state$final_models
      
      c_desc <- if (!is.null(m$descriptive)) "fillcolor = '#2ecc71', fontcolor = white" else "fillcolor = '#ecf0f1', fontcolor = black"
      c_norm <- if (!is.null(m$normality))   "fillcolor = '#2ecc71', fontcolor = white" else "fillcolor = '#ecf0f1', fontcolor = black"
      c_hyp  <- if (!is.null(m$hypothesis))  "fillcolor = '#2ecc71', fontcolor = white" else "fillcolor = '#ecf0f1', fontcolor = black"
      c_reg  <- if (!is.null(m$linear_reg) || !is.null(m$logistic_reg)) "fillcolor = '#2ecc71', fontcolor = white" else "fillcolor = '#ecf0f1', fontcolor = black"
      
      grViz(sprintf("
        digraph workflow {
          graph [layout = dot, rankdir = LR]
          node [shape = rectangle, style = filled, fontname = Helvetica]
          
          Data [label = 'Data Loaded', fillcolor = '#3498db', fontcolor = white]
          Desc [label = 'Descriptives', %s]
          Norm [label = 'Normality Test', %s]
          Hyp  [label = 'Hypothesis Test', %s]
          Reg  [label = 'Regression Model', %s]
          
          Data -> Desc -> Norm -> Hyp -> Reg
        }
      ", c_desc, c_norm, c_hyp, c_reg))
    })
    
    # Report UI Summary
    output$report_summary <- renderUI({
      m <- app_state$final_models
      tagList(
        h5("Completed Analysis Modules:"),
        tags$ul(
          tags$li(if(!is.null(m$descriptive)) paste("Descriptives:", m$descriptive$variable) else "Descriptives: Pending"),
          tags$li(if(!is.null(m$normality)) paste("Normality Test:", m$normality$variable) else "Normality Test: Pending"),
          tags$li(if(!is.null(m$hypothesis)) paste("Hypothesis Test:", m$hypothesis$test_type) else "Hypothesis Test: Pending"),
          tags$li(if(!is.null(m$linear_reg) || !is.null(m$logistic_reg)) "Regression Analysis: Completed" else "Regression Analysis: Pending")
        )
      )
    })
    
    # Download Word Report Handler
    output$download_docx <- downloadHandler(
      filename = function() { paste0("SURVLYTICS_Analysis_Report_", Sys.Date(), ".docx") },
      content = function(file) {
        doc <- read_docx()
        
        # --- Cover / Document Header ---
        doc <- body_add_par(doc, "SURVLYTICS Statistical Analysis Report", style = "heading 1")
        doc <- body_add_par(doc, paste("Generated on:", format(Sys.time(), "%B %d, %Y - %H:%M")), style = "Normal")
        
        if (!is.null(app_state$data)) {
          doc <- body_add_par(doc, paste("Dataset Dimensions:", nrow(app_state$data), "rows x", ncol(app_state$data), "columns"), style = "Normal")
        }
        doc <- body_add_par(doc, "---------------------------------------------------------------------------------------------------", style = "Normal")
        
        m <- app_state$final_models
        
        # --- 1. Descriptive Statistics ---
        if(!is.null(m$descriptive)) {
          doc <- body_add_par(doc, paste("1. Descriptive Statistics:", m$descriptive$variable), style = "heading 2")
          
          df_desc <- m$descriptive$summary
          if ("Value" %in% names(df_desc) && is.numeric(df_desc$Value)) {
            df_desc$Value <- round(df_desc$Value, 3)
          }
          ft_desc <- flextable(df_desc) %>% autofit() %>% theme_vanilla()
          doc <- body_add_flextable(doc, ft_desc)
          doc <- body_add_par(doc, "", style = "Normal") # Blank line spacer
        }
        
        # --- 2. Normality Testing ---
        if(!is.null(m$normality)) {
          doc <- body_add_par(doc, paste("2. Normality Test:", m$normality$variable), style = "heading 2")
          
          p_val <- round(m$normality$p_value, 4)
          interp <- if(p_val > 0.05) {
            "The data follows a normal distribution (p > 0.05). Parametric tests are appropriate."
          } else {
            "The data significantly deviates from a normal distribution (p <= 0.05). Consider non-parametric alternatives."
          }
          
          norm_df <- data.frame(
            Metric = c("Variable Tested", "Test Method", "p-value", "Conclusion"),
            Value = c(m$normality$variable, m$normality$test_name, as.character(p_val), interp)
          )
          ft_norm <- flextable(norm_df) %>% autofit() %>% theme_vanilla()
          doc <- body_add_flextable(doc, ft_norm)
          doc <- body_add_par(doc, "", style = "Normal")
        }
        
        # --- 3. Hypothesis Testing ---
        if(!is.null(m$hypothesis)) {
          doc <- body_add_par(doc, paste("3. Hypothesis Testing (", m$hypothesis$test_type, ")"), style = "heading 2")
          doc <- body_add_par(doc, paste("Comparison:", m$hypothesis$var_x, "vs", m$hypothesis$var_y), style = "Normal")
          
          # Convert test result object into clean table format if possible
          if (inherits(m$hypothesis$result, "anova") || inherits(m$hypothesis$result, "summary.aov")) {
            aov_table <- as.data.frame(m$hypothesis$result[[1]])
            aov_table <- cbind(Source = rownames(aov_table), aov_table)
            rownames(aov_table) <- NULL
            num_cols <- sapply(aov_table, is.numeric)
            aov_table[num_cols] <- lapply(aov_table[num_cols], function(x) round(x, 4))
            
            ft_hyp <- flextable(aov_table) %>% autofit() %>% theme_vanilla()
            doc <- body_add_flextable(doc, ft_hyp)
          } else {
            # General fallback text print for t-test or chi-square
            txt_res <- paste(capture.output(print(m$hypothesis$result)), collapse = "\n")
            doc <- body_add_par(doc, txt_res, style = "Normal")
          }
          doc <- body_add_par(doc, "", style = "Normal")
        }
        
        # --- 4. Regression Analysis ---
        if(!is.null(m$linear_reg)) {
          doc <- body_add_par(doc, "4. Linear Regression Model Summary", style = "heading 2")
          doc <- body_add_par(doc, paste("Model Formula:", m$linear_reg$formula), style = "Normal")
          
          if (!is.null(m$linear_reg$result)) {
            sm <- summary(m$linear_reg$result)
            coef_df <- as.data.frame(sm$coefficients)
            coef_df <- cbind(Predictor = rownames(coef_df), coef_df)
            rownames(coef_df) <- NULL
            
            num_cols <- sapply(coef_df, is.numeric)
            coef_df[num_cols] <- lapply(coef_df[num_cols], function(x) round(x, 4))
            
            ft_reg <- flextable(coef_df) %>% autofit() %>% theme_vanilla()
            doc <- body_add_flextable(doc, ft_reg)
            doc <- body_add_par(doc, paste("R-squared:", round(sm$r.squared, 4), "| Adjusted R-squared:", round(sm$adj.r.squared, 4)), style = "Normal")
          }
        } else if(!is.null(m$logistic_reg)) {
          doc <- body_add_par(doc, "4. Logistic Regression Model Summary", style = "heading 2")
          doc <- body_add_par(doc, paste("Binary Outcome Variable:", m$logistic_reg$dep_var), style = "Normal")
          
          if (!is.null(m$logistic_reg$result)) {
            coef_df <- as.data.frame(m$logistic_reg$result$coefficients)
            coef_df <- cbind(Predictor = rownames(coef_df), coef_df)
            rownames(coef_df) <- NULL
            
            num_cols <- sapply(coef_df, is.numeric)
            coef_df[num_cols] <- lapply(coef_df[num_cols], function(x) round(x, 4))
            
            ft_reg <- flextable(coef_df) %>% autofit() %>% theme_vanilla()
            doc <- body_add_flextable(doc, ft_reg)
          }
        }
        
        print(doc, target = file)
      }
    )
  })
}