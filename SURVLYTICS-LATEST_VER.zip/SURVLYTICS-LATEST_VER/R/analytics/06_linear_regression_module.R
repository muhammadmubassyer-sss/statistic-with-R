linear_regression_ui <- function(id) {
  ns <- NS(id)
  tagList(
    layout_sidebar(
      sidebar = sidebar(
        selectInput(ns("dep_var"), "Dependent Variable (Y):", choices = NULL),
        selectizeInput(ns("indep_vars"), "Independent Variable(s) (X):", choices = NULL, multiple = TRUE),
        actionButton(ns("run_lm"), "Fit Model & Save", class = "btn-primary w-100")
      ),
      card(
        card_header("Linear Regression Summary"),
        verbatimTextOutput(ns("lm_summary"))
      )
    )
  )
}

linear_regression_server <- function(id, app_state) {
  moduleServer(id, function(input, output, session) {
    
    observe({
      req(app_state$data)
      num_vars <- names(app_state$data)[sapply(app_state$data, is.numeric)]
      updateSelectInput(session, "dep_var", choices = num_vars)
      updateSelectizeInput(session, "indep_vars", choices = num_vars)
    })
    
    lm_res <- eventReactive(input$run_lm, {
      req(input$dep_var, input$indep_vars, app_state$data)
      
      formula_str <- paste(input$dep_var, "~", paste(input$indep_vars, collapse = " + "))
      fit <- lm(as.formula(formula_str), data = app_state$data)
      
      # Save state to trigger green box in workflow
      app_state$final_models$linear_reg <- list(
        formula = formula_str,
        summary = summary(fit)
      )
      
      fit
    })
    
    output$lm_summary <- renderPrint({
      req(lm_res())
      summary(lm_res())
    })
  })
}