normality_ui <- function(id) {
  ns <- NS(id)
  tagList(
    layout_sidebar(
      sidebar = sidebar(
        selectInput(ns("norm_var"), "Select Continuous Variable:", choices = NULL),
        selectInput(ns("test_type"), "Select Test:", choices = c("Shapiro-Wilk", "Kolmogorov-Smirnov", "Anderson-Darling")),
        actionButton(ns("run_norm"), "Run & Save to Report", class = "btn-primary w-100")
      ),
      card(
        card_header("Normality Test Result"),
        verbatimTextOutput(ns("norm_result")),
        plotOutput(ns("qq_plot"))
      )
    )
  )
}

normality_server <- function(id, app_state) {
  moduleServer(id, function(input, output, session) {
    
    observe({
      req(app_state$data)
      num_vars <- names(app_state$data)[sapply(app_state$data, is.numeric)]
      updateSelectInput(session, "norm_var", choices = num_vars)
    })
    
    test_res <- eventReactive(input$run_norm, {
      req(input$norm_var, app_state$data)
      val <- app_state$data[[input$norm_var]]
      val <- na.omit(val)
      
      res <- switch(input$test_type,
                    "Shapiro-Wilk" = shapiro.test(val),
                    "Kolmogorov-Smirnov" = ks.test(val, "pnorm", mean(val), sd(val)),
                    "Anderson-Darling" = nortest::ad.test(val)
      )
      
      app_state$final_models$normality <- list(
        variable = input$norm_var,
        test_name = input$test_type,
        p_value = res$p.value,
        is_normal = res$p.value > 0.05
      )
      
      res
    })
    
    output$norm_result <- renderPrint({
      req(test_res())
      test_res()
    })
    
    output$qq_plot <- renderPlot({
      req(input$norm_var, app_state$data)
      qqnorm(app_state$data[[input$norm_var]], main = paste("Q-Q Plot for", input$norm_var))
      qqline(app_state$data[[input$norm_var]], col = "red")
    })
  })
}