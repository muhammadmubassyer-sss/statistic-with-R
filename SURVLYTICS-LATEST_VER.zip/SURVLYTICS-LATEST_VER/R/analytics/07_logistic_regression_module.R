logistic_regression_ui <- function(id) {
  ns <- NS(id)
  tagList(
    layout_sidebar(
      sidebar = sidebar(
        selectInput(ns("dep_var"), "Binary Outcome (Y):", choices = NULL),
        selectizeInput(ns("indep_vars"), "Predictor Variables (X):", choices = NULL, multiple = TRUE),
        actionButton(ns("run_glm"), "Fit Model & Save", class = "btn-primary w-100")
      ),
      card(
        card_header("Logistic Regression Summary"),
        verbatimTextOutput(ns("glm_summary"))
      )
    )
  )
}

logistic_regression_server <- function(id, app_state) {
  moduleServer(id, function(input, output, session) {
    
    observe({
      req(app_state$data)
      updateSelectInput(session, "dep_var", choices = names(app_state$data), selected = "Species")
      updateSelectizeInput(session, "indep_vars", choices = names(app_state$data)[sapply(app_state$data, is.numeric)], selected = c("Sepal.Length", "Sepal.Width"))
    })
    
    glm_res <- eventReactive(input$run_glm, {
      req(input$dep_var, input$indep_vars, app_state$data)
      df <- app_state$data
      
      res <- tryCatch({
        # If user chooses a factor/character (like Species), convert to binary (1 vs rest)
        if (!is.numeric(df[[input$dep_var]]) || length(unique(df[[input$dep_var]])) > 2) {
          first_level <- unique(df[[input$dep_var]])[1]
          df[[input$dep_var]] <- ifelse(df[[input$dep_var]] == first_level, 1, 0)
        }
        
        formula_str <- paste(input$dep_var, "~", paste(input$indep_vars, collapse = " + "))
        fit <- glm(as.formula(formula_str), data = df, family = binomial)
        summary(fit)
      }, error = function(e) {
        paste("Error running Logistic Regression:", e$message, "\nTip: Make sure Y is a binary variable (0/1 or two categories) or use Linear Regression for numeric values.")
      })
      
      # Save model state to turn the Regression box GREEN in the workflow diagram
      app_state$final_models$logistic_reg <- list(
        dep_var = input$dep_var,
        indep_vars = input$indep_vars,
        result = res
      )
      
      res
    })
    
    output$glm_summary <- renderPrint({
      req(glm_res())
      glm_res()
    })
  })
}